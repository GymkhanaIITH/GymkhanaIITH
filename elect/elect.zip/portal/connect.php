<?php
$db_host='localhost';
$db_database='elect';
$db_username='root';
$db_password='Omega9889$';
$db_server=mysqli_connect($db_host,$db_username,$db_password, $db_database);
?>
