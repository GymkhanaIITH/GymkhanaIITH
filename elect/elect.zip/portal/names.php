<?php
$data=[["President", "Aayush Kumar", "Solomon S"],
["General Secretary", "Harsh Jain", "Vishwajith Rathod"],
["General Secretary 2","Ganna Sri Laxmi"],
["Sports Secretary", "Jeevan Chandra", "Shreyash Anarase"],
["Science and Technology Secretary", "Aithu Snehith"],
["Academic Affairs Secretary", "Anand N Warrier", "Abhilash Reddy"],
["Cultural Affairs Secretary", "Rahul Alam", "K Raja Pradyumna"],
["UG Representative", "Lokesh Reddy", "Anvesh Bendalam"],
["UG Representative 2","Uma Reddy S"],
["PG Representative", "Uttaran Sinha"], 
["PhD Representative II", "Priyanka Goyal"],
["Mess Secretary", "Kollipara Anirudh"]];
?>
